from PIL import Image
from PIL import ImageChops 

def compare_images(path_one, path_two, diff_save_location):
    image_one = Image.open(path_one)
    image_two = Image.open(path_two)
    try:
        diff = ImageChops.difference(image_one, image_two)
        if diff.getbbox() is None:
            # 圖片間沒有任何不同則直接退出
            print("【+】We are the same!")
        else:
            diff.save(diff_save_location)

    except ValueError as e:
        text = ("表示圖片大小和box對應的寬度不一致，參考API說明：Pastes another image into this image."
                "The box argument is either a 2-tuple giving the upper left corner, a 4-tuple defining the left, upper, "
                "right, and lower pixel coordinate, or None (same as (0, 0)). If a 4-tuple is given, the size of the pasted "
                "image must match the size of the region.使用2緯的box避免上述問題")
        print("【{0}】{1}".format(e,text))

if __name__ == '__main__':
    compare_images('001.jpg',
                   '002.jpg',
                   '我們不一樣.jpg')