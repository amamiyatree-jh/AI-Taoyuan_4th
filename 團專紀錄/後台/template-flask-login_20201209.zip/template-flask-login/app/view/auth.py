from flask import Flask, render_template, request, session
from flask import Blueprint, make_response, url_for, redirect, jsonify
from flask_restful import Api, Resource, reqparse
from marshmallow import ValidationError
from ..model.user import UserModel, UserSchema
from .. import db
from .abort_msg import abort_msg
from functools import wraps
import json

auth = Blueprint('auth', __name__,
    template_folder='templates',
    static_folder='static')
api = Api(auth)

users_schema = UserSchema()


class Signup(Resource):
    def post(self):
        try:
            # 資料驗證
            user_data = users_schema.load(request.form, partial=True)
            # 註冊
            new_user = UserModel(user_data)
            new_user.save_db()
            new_user.save_session()
            #return {'msg': 'registration success'}, 200
            return make_response(render_template('page-regok.html'))

        except ValidationError as error:
            return {'errors': error.messages}, 400

        except Exception as e:
            return {'errors': abort_msg(e)}, 500

    def get(self):
        return make_response(render_template('signup.html'))


class Login(Resource):
    def post(self):
        try:
            # 資料驗證
            user_data = users_schema.load(request.form)
            name = user_data['name']
            password = user_data['password']

            # 登入~~~~~
            query = UserModel.get_user(name)
            if query != None and query.verify_password(password):
                query.save_session()
                session.permanent = True
                #session['role'] = 'logined'
                #return {'msg': 'ok'}, 200
                #return make_response(render_template('dashindex.html'))
                #Login.check_login(session['role'])
                return redirect('../' + session['username'])
                #return 'ok'
            else:
                return {'errors': 'incorrect username or password'}, 400

        except ValidationError as error:
            return {'errors': error.messages}, 400

        except Exception as e:
            return {'errors': abort_msg(e)}, 500

    def get(self):
        return make_response(render_template('login.html'))

    def check_login(check_role):
        def decorator(func):
            def wrap(*args, **kw):
                user_role = session.get('role')

                if user_role == None or user_role == '':
                    return abort(401)
                else:
                    if check_role == 'admin' and check_role == user_role:
                        return func(*args, **kw)
                    if check_role == 'normal':
                        return func(*args, **kw)
                    else:
                        return abort(401)

                wrap.__name__ = func.__name__
                return wrap
            return decorator
        if session.get('role') == 'normal':
            rentrun_page_name = 'nor_dashindex.html'
            data_PushtoHTML = {
            'username' : session['username'],
            'role' : session['role'],
            'uid' : session['uid']
            }
            push_dtohtml = render_template(rentrun_page_name, data_pushtohtml = data_PushtoHTML)
        if session.get('role') == 'admin':
            rentrun_page_name = 'adm_dashindex.html'
            data_PushtoHTML = {
            'username' : session['username'],
            'role' : session['role'],
            'uid' : session['uid'],
            }
            push_dtohtml = render_template(rentrun_page_name, data_pushtohtml = data_PushtoHTML)
        return push_dtohtml

class Logout(Resource):
    def get(self):
        UserModel.remove_session()
        #return {'msg': 'logout'}, 200
        return make_response(render_template('logout-page.html'))

api.add_resource(Signup, '/signup')
api.add_resource(Login, '/login')
api.add_resource(Logout, '/logout')