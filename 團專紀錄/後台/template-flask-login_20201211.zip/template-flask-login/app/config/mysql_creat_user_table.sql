CREATE TABLE `user` (
	uid INTEGER NOT NULL AUTO_INCREMENT, 
	name VARCHAR(30), 
	password_hash VARCHAR(255), 
	role VARCHAR(10), 
	insert_time DATETIME, 
	update_time DATETIME, 
	PRIMARY KEY (uid), 
	UNIQUE (name)
);
