import os
from datetime import timedelta
import pymysql

basedir = os.path.abspath(os.path.dirname(__file__))


def create_sqlite_uri(db_name):
    return "sqlite:///" + os.path.join(basedir, db_name)

def create_mysql_uri(db_name):
    #return "mysql+pymysql://XNZ6lJDg4E:XcmF3lSgNz@remotemysql.com:3306/" + db_name
    return "mysql+pymysql://root@localhost:3306/" + db_name
#app.config['SQLALCHEMY_DATABASE_URI'] = "mysql+pymysql://user_name:password@IP:3306/db_name"

class BaseConfig:  # 基本配置
    #SECRET_KEY = os.environ.get('key')
    SECRET_KEY = os.urandom(24)
    PERMANENT_SESSION_LIFETIME = timedelta(days=14)


class DevelopmentConfig(BaseConfig):
    DEBUG = False
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = os.environ.get('db')
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 3600,
    }
    # ?ssl_key=config/client-key.pem&ssl_cert=config/client-cert.pem"


class TestingConfig(BaseConfig):
    TESTING = True
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = create_sqlite_uri("test.db")
    WTF_CSRF_ENABLED = False

class TestingConfigMysql(BaseConfig):
    TESTING = True
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = create_mysql_uri("backstage_db")
    #SQLALCHEMY_DATABASE_URI = create_mysql_uri("XNZ6lJDg4E")
    WTF_CSRF_ENABLED = False
    SECRET_KEY = os.urandom(24)
    PERMANENT_SESSION_LIFETIME = timedelta(days=31)
    #static_folder = "./LINEbot/"

config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig,
    'testingmysql': TestingConfigMysql
}
